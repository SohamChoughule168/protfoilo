import Image from 'next/image'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-gray-800 text-white p-4 fixed w-full top-0 z-10">
        <nav>
          <ul className="flex justify-center space-x-4">
            <li><Link href="#home" className="hover:text-gray-300">Home</Link></li>
            <li><Link href="#about" className="hover:text-gray-300">About</Link></li>
            <li><Link href="#education" className="hover:text-gray-300">Education</Link></li>
            <li><Link href="#projects" className="hover:text-gray-300">Projects</Link></li>
            <li><Link href="#skills" className="hover:text-gray-300">Skills</Link></li>
            <li><Link href="#contact" className="hover:text-gray-300">Contact</Link></li>
          </ul>
        </nav>
      </header>

      <main className="flex-grow mt-16">
        <section id="home" className="min-h-screen flex items-center justify-center bg-gray-100">
          <div className="text-center">
            <Image
              src="/placeholder.svg"
              alt="Soham Rohidas Choughule"
              width={200}
              height={200}
              className="rounded-full mx-auto mb-4"
            />
            <h1 className="text-4xl font-bold mb-2">Soham Rohidas Choughule</h1>
            <p className="text-xl">Computer Science Engineering Student (AI/ML)</p>
            <p className="mt-2">Mumbai, Maharashtra, India</p>
            <p>sohamchoughule06@gmail.com • +91 8850469410</p>
          </div>
        </section>

        <section id="about" className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">About Me</h2>
            <p className="text-lg max-w-2xl mx-auto">
              I am a passionate Computer Science Engineering student specializing in AI/ML. With a strong foundation in algorithm development and machine learning techniques, I am constantly exploring new technologies and contributing to open-source projects. My goal is to leverage my skills in Python, Java, and C++ to create innovative solutions in the field of artificial intelligence and machine learning.
            </p>
          </div>
        </section>

        <section id="education" className="py-16 bg-gray-100">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Education</h2>
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold">G.V.Acharya Institute of Engineering and Technology</h3>
                <p>Karjat, India</p>
                <p>Computer Science Engineering AI/ML</p>
                <p>Expected Graduation: 2026</p>
                <p>Relevant Coursework: Algorithm Development, Machine Learning Techniques</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold">S. H Jondhale Polytechnic</h3>
                <p>Dombivili, India</p>
                <p>Diploma in Computer Engineering</p>
                <p>Completed: 2023</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold">Model English High School</h3>
                <p>Dombivili, India</p>
                <p>Grade: 7.5 CGPA</p>
                <p>Completed: 2019</p>
              </div>
            </div>
          </div>
        </section>

        <section id="projects" className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Projects</h2>
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold">Wikipedia-style Online Encyclopedia Project</h3>
                <p className="italic">CS50w Web Project, Harvard University (Completed 2023)</p>
                <ul className="list-disc list-inside mt-2">
                  <li>Developed a dynamic web application using Django framework</li>
                  <li>Implemented CRUD functionalities for encyclopedia entries</li>
                  <li>Utilized HTML, CSS, and JavaScript for a responsive user interface</li>
                  <li>Integrated Markdown syntax for formatting encyclopedia entries</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-semibold">Face Detection Using Python</h3>
                <p className="italic">Diploma Project (Completed 2022)</p>
                <ul className="list-disc list-inside mt-2">
                  <li>Implemented a robust face detection system using Python and OpenCV</li>
                  <li>Achieved high accuracy in detecting faces in images and real-time video streams</li>
                  <li>Developed a user-friendly interface for easy interaction and deployment</li>
                  <li>Conducted rigorous testing and optimization to enhance performance and reliability</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section id="skills" className="py-16 bg-gray-100">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Skills & Interests</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-2">Technical Skills</h3>
                <p>Python, Java, C++, TensorFlow, PyTorch, OpenCV, HTML, CSS, JavaScript</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Languages</h3>
                <p>English, Hindi, Marathi</p>
              </div>
              <div className="md:col-span-2">
                <h3 className="text-xl font-semibold mb-2">Interests</h3>
                <p>Exploring new technologies, staying updated with industry trends, contributing to open-source projects, and collaborative coding initiatives</p>
              </div>
            </div>
          </div>
        </section>

        <section id="certifications" className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Certifications</h2>
            <ul className="list-disc list-inside space-y-2">
              <li>Completed "Programming For Everybody: Getting Started with Python" course from University of Michigan</li>
              <li>Completed "CS50's Introduction to Programming with Python" course from Harvard University</li>
            </ul>
          </div>
        </section>

        <section id="contact" className="py-16 bg-gray-100">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Contact Me</h2>
            <form className="max-w-md mx-auto">
              <div className="mb-4">
                <label htmlFor="name" className="block mb-2">Name</label>
                <input type="text" id="name" name="name" className="w-full p-2 border rounded" required />
              </div>
              <div className="mb-4">
                <label htmlFor="email" className="block mb-2">Email</label>
                <input type="email" id="email" name="email" className="w-full p-2 border rounded" required />
              </div>
              <div className="mb-4">
                <label htmlFor="message" className="block mb-2">Message</label>
                <textarea id="message" name="message" rows={4} className="w-full p-2 border rounded" required></textarea>
              </div>
              <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Send Message</button>
            </form>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white p-4 text-center">
        <p>&copy; 2023 Soham Rohidas Choughule. All rights reserved.</p>
        <Link href="/resume.pdf" target="_blank" className="text-blue-300 hover:underline">
          Download Resume (PDF)
        </Link>
      </footer>
    </div>
  )
}

