'use client'

import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Github, Linkedin, Mail, Download, ExternalLink } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-50 to-white">
      <header className="bg-white/80 backdrop-blur-sm text-gray-800 p-4 fixed w-full top-0 z-10 border-b">
        <nav className="max-w-6xl mx-auto">
          <ul className="flex justify-center space-x-8">
            {['Home', 'About', 'Education', 'Projects', 'Skills', 'Contact'].map((item) => (
              <li key={item}>
                <Link 
                  href={`#${item.toLowerCase()}`} 
                  className="hover:text-yellow-600 transition-colors font-medium"
                >
                  {item}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </header>

      <main className="pt-16">
        <section id="home" className="min-h-[90vh] flex items-center justify-center py-20">
          <div className="container px-4 grid md:grid-cols-2 gap-8 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center md:text-left"
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-yellow-600 to-yellow-400 text-transparent bg-clip-text">
                Soham Rohidas Choughule
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 mb-6">
                Computer Science Engineering Student (AI/ML)
              </p>
              <p className="text-gray-600 mb-8">Mumbai, Maharashtra, India</p>
              <div className="flex gap-4 justify-center md:justify-start">
                <Button variant="outline" className="gap-2">
                  <Github className="w-4 h-4" />
                  GitHub
                </Button>
                <Button variant="outline" className="gap-2">
                  <Linkedin className="w-4 h-4" />
                  LinkedIn
                </Button>
                <Button variant="outline" className="gap-2">
                  <Mail className="w-4 h-4" />
                  Email
                </Button>
              </div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="relative"
            >
              <div className="relative w-72 h-72 mx-auto overflow-hidden rounded-2xl shadow-xl">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202023-12-17%20at%2012.38.57%20AM-fAUdCjAtol7T6Q2pcg3w9yIFBUJ1YR.jpeg"
                  alt="Soham Rohidas Choughule"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            </motion.div>
          </div>
        </section>

        <section id="about" className="py-20 bg-white">
          <div className="container px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-center mb-12 bg-gradient-to-r from-yellow-600 to-yellow-400 text-transparent bg-clip-text">
                About Me
              </h2>
              <Card className="max-w-3xl mx-auto">
                <CardContent className="p-6">
                  <p className="text-lg text-gray-600 leading-relaxed">
                    I am a passionate Computer Science Engineering student specializing in AI/ML at G.V.Acharya Institute of Engineering and Technology. With a strong foundation in algorithm development and machine learning techniques, I am constantly exploring new technologies and contributing to open-source projects. My goal is to leverage my skills in Python, Java, and C++ to create innovative solutions in the field of artificial intelligence and machine learning.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>

        <section id="education" className="py-20 bg-yellow-50">
          <div className="container px-4">
            <h2 className="text-3xl font-bold text-center mb-12 bg-gradient-to-r from-yellow-600 to-yellow-400 text-transparent bg-clip-text">
              Education Journey
            </h2>
            <div className="max-w-4xl mx-auto space-y-8">
              {[
                {
                  school: "G.V.Acharya Institute of Engineering and Technology",
                  location: "Karjat, India",
                  degree: "Computer Science Engineering AI/ML",
                  year: "Expected Graduation: 2026",
                  details: "Relevant Coursework: Algorithm Development, Machine Learning Techniques"
                },
                {
                  school: "S. H Jondhale Polytechnic",
                  location: "Dombivili, India",
                  degree: "Diploma in Computer Engineering",
                  year: "Completed: 2023"
                },
                {
                  school: "Model English High School",
                  location: "Dombivili, India",
                  degree: "High School",
                  year: "Completed: 2019",
                  details: "Grade: 7.5 CGPA"
                }
              ].map((edu, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold text-yellow-600">{edu.school}</h3>
                      <p className="text-gray-600">{edu.location}</p>
                      <p className="font-medium">{edu.degree}</p>
                      <p className="text-gray-500">{edu.year}</p>
                      {edu.details && <p className="text-gray-600 mt-2">{edu.details}</p>}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section id="projects" className="py-20 bg-white">
          <div className="container px-4">
            <h2 className="text-3xl font-bold text-center mb-12 bg-gradient-to-r from-yellow-600 to-yellow-400 text-transparent bg-clip-text">
              Featured Projects
            </h2>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {[
                {
                  title: "Wikipedia-style Online Encyclopedia",
                  type: "CS50w Web Project, Harvard University",
                  year: "2023",
                  points: [
                    "Developed a dynamic web application using Django framework",
                    "Implemented CRUD functionalities for encyclopedia entries",
                    "Utilized HTML, CSS, and JavaScript for a responsive interface",
                    "Integrated Markdown syntax for formatting encyclopedia entries"
                  ]
                },
                {
                  title: "Face Detection System",
                  type: "Diploma Project",
                  year: "2022",
                  points: [
                    "Implemented robust face detection using Python and OpenCV",
                    "Achieved high accuracy in real-time video streams",
                    "Developed a user-friendly interface",
                    "Conducted rigorous testing and optimization"
                  ]
                }
              ].map((project, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold text-yellow-600 mb-2">{project.title}</h3>
                      <p className="text-gray-500 mb-4">{project.type} • {project.year}</p>
                      <ul className="space-y-2">
                        {project.points.map((point, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-yellow-600 mt-1">•</span>
                            <span className="text-gray-600">{point}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section id="skills" className="py-20 bg-yellow-50">
          <div className="container px-4">
            <h2 className="text-3xl font-bold text-center mb-12 bg-gradient-to-r from-yellow-600 to-yellow-400 text-transparent bg-clip-text">
              Skills & Certifications
            </h2>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
              >
                <Card className="h-full">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold text-yellow-600 mb-4">Technical Skills</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Programming Languages</h4>
                        <p className="text-gray-600">Python, Java, C++</p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Frameworks & Tools</h4>
                        <p className="text-gray-600">TensorFlow, PyTorch, OpenCV</p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Web Technologies</h4>
                        <p className="text-gray-600">HTML, CSS, JavaScript</p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Languages</h4>
                        <p className="text-gray-600">English, Hindi, Marathi</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
              >
                <Card className="h-full">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold text-yellow-600 mb-4">Certifications</h3>
                    <div className="space-y-4">
                      <div className="flex items-start gap-2">
                        <ExternalLink className="w-5 h-5 text-yellow-600 mt-1" />
                        <div>
                          <p className="font-medium">Programming For Everybody: Getting Started with Python</p>
                          <p className="text-gray-500">University of Michigan</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <ExternalLink className="w-5 h-5 text-yellow-600 mt-1" />
                        <div>
                          <p className="font-medium">CS50's Introduction to Programming with Python</p>
                          <p className="text-gray-500">Harvard University</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        <section id="contact" className="py-20 bg-white">
          <div className="container px-4">
            <h2 className="text-3xl font-bold text-center mb-12 bg-gradient-to-r from-yellow-600 to-yellow-400 text-transparent bg-clip-text">
              Get In Touch
            </h2>
            <Card className="max-w-xl mx-auto">
              <CardContent className="p-6">
                <form className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                    <input
                      type="text"
                      id="name"
                      className="w-full p-2 border rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input
                      type="email"
                      id="email"
                      className="w-full p-2 border rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                    <textarea
                      id="message"
                      rows={4}
                      className="w-full p-2 border rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-white">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container px-4 mx-auto text-center">
          <div className="flex justify-center space-x-6 mb-4">
            <Button variant="ghost" size="icon">
              <Github className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Linkedin className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Mail className="w-5 h-5" />
            </Button>
          </div>
          <p className="text-gray-400">© 2023 Soham Rohidas Choughule. All rights reserved.</p>
          <Button variant="ghost" className="mt-4 gap-2">
            <Download className="w-4 h-4" />
            Download Resume
          </Button>
        </div>
      </footer>
    </div>
  )
}

